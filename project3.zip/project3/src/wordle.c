#include "wordle.h"

#include <string.h>

#include "ctype.h"
#include "dict.h"
#include "util.h"

bool compareTwoQuantum(char *selected1, char *selected2, int k) {
    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            if (selected1[i] == selected2[j]) {
                return false;
            }
        }
    }
    return true;
}

Trie *generateDict(char *filename, int k, /*@out@*/ char *selected1,
                   /*@out@*/ char *selected2) {
    int rand_word1, rand_word2;

    // int ra
    Trie *dict = create();  // creating root node

    FILE *f = fopen(filename, "r");

    char *str = malloc(k + 2);  // to iterate over all the strings in the file
    int num_words_iter = 0;
    int total_words = 0;

    while (true) {
        if (fgets(str, k + 2, f) == NULL) break;
        str[k] = '\0';
        insert(dict, str);  // inserting string in the dict
        total_words += 1;
    }

    free(str);

    fclose(f);

    // selecting first word
    rand_word1 = (int)drand48() * total_words;
    f = fopen(filename, "r");
    while (true) {
        if (fgets(selected1, k + 1, f) == NULL) break;

        if (selected1[0] == '\n') continue;
        if (num_words_iter == rand_word1) {
            break;
        }
        num_words_iter = +1;
    }
    fclose(f);

    // selecting second word
    if (selected2 != NULL) {
        do {
            do {
                rand_word2 = (int)drand48() * total_words;
            } while (rand_word1 == rand_word2);
            f = fopen(filename, "r");
            num_words_iter = 0;
            while (true) {
                if (fgets(selected2, k + 1, f) == NULL) break;

                if (selected2[0] == '\n') continue;
                if (num_words_iter == rand_word2) {
                    break;
                }
                num_words_iter = +1;
            }
            fclose(f);
        } while (compareTwoQuantum(selected1, selected2, k));
    }
    return dict;
}

// function to uppercase -> lowercase
void get_lower(char *str, int k) {
    // use for loop to iterate the length of the string
    for (int i = 0; i < k; i++) {
        if (str[i] >= 65 && str[i] <= 90) {
            str[i] =
                str[i] +
                32; /* add 32 to string character to change into lowercase */
        }
    }
}

char *guess(Trie *dict, int k) {
    char *valid_word = NULL;
    size_t a = 0;
    printf("Please input your guess: ");

    while (true) {  // loop till the time input is invalid

        getline(&valid_word, &a, stdin);  // input the line

        get_lower(valid_word, k);

        if ((int)strlen(valid_word) == (k + 1)) {
            valid_word[k] = '\0';
            if (dict == NULL) {  // if trei is empty
                return valid_word;
            }
            if (lookup(dict,
                       valid_word)) {  // if word is in dictionary return it
                return valid_word;
            }
        }

        printf("Invalid word. Try again: ");
    }
}

int getCharIndex(char c) { return ((int)c - 97); }

feedback_result *getFeedback(char *guess, char *word1, char *word2, int k) {
    feedback_result *feedback_array =
        malloc(k * sizeof(CORRECT));  // creating the array pointer
    int cguess[26], cword1[26];
    int letter_index;

    for (int i = 0; i < 26; i++) {  // all the values = 0
        cguess[i] = 0;
        cword1[i] = 0;
    }

    for (int i = 0; i < k; i++) {  // count the number of occurrences in each
                                   // word in guess and word1
        cguess[getCharIndex(guess[i])] += 1;
        cword1[getCharIndex(word1[i])] += 1;
        feedback_array[i] = WRONG;  // all elements to WRONG
    }

    for (int i = 0; i < k; i++) {  // marking all the correct position words
        if (guess[i] == word1[i]) {
            feedback_array[i] = CORRECT;
            cguess[getCharIndex(guess[i])] -= 1;
            cword1[getCharIndex(word1[i])] -= 1;
        }
    }

    for (int i = 0; i < k; i++) {  // marking all the wrong position words
        letter_index = getCharIndex(guess[i]);
        if (cguess[letter_index] != 0 && cword1[letter_index] != 0 &&
            feedback_array[i] != CORRECT) {
            feedback_array[i] = WRONGPOS;
            cguess[letter_index] -= 1;
            cword1[letter_index] -= 1;
        }
    }
    return feedback_array;
}
void printFeedback(feedback_result *feedback, int k) {
    printf("Result: ");
    for (int i = 0; i < k; i++) {
        // switch to print
        switch (feedback[i]) {
            case CORRECT:
                printf(CORRECT_UNICODE);
                break;
            case WRONGPOS:
                printf(PRESENT_UNICODE);
                break;
            case WRONG:
                printf(WRONG_UNICODE);
                break;
            case QUANTUMCORRECT:
                printf(QCORRECT_UNICODE);
                break;
            case QUANTUMWRONGPOS:
                printf(QPRESENT_UNICODE);
                break;
        }
    }
    printf("\n");
}
bool checkWin(feedback_result *feedback, int k) {
    for (int i = 0; i < k; i++) {
        if (feedback[i] !=
            CORRECT) {  // if any element is not correct the return false
            return false;
        }
    }
    return true;
}