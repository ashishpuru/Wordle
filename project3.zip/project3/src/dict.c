#include "dict.h"

#include <stdbool.h>
#include <stdlib.h>
//#include <cstring>
#include <string.h>

#define NUM_CHARS 26  // total number of alphabets in english letters

// Converts key current character into index
// use only 'a' through 'z' and lower case
#define CHAR_TO_INDEX(c) ((int)c - (int)'a')

struct Trie {
    struct Trie *children[NUM_CHARS];
    bool is_leaf;
};

struct Trie *create() {
    // creating the node
    Trie *new_node = (Trie *)malloc(sizeof(Trie));

    if (new_node) {
        new_node->is_leaf = false;  // is_leaf is null

        for (int i = 0; i < NUM_CHARS;
             i++) {  // all children nodes should be null
            new_node->children[i] = NULL;
        }
    }
    return new_node;
}

void insert(Trie *dict, char *str) {
    int str_length = strlen(str);
    int index;

    if (dict == NULL) {
        dict = create();
    }

    Trie *tmp = dict;
    for (int i = 0; i < str_length; i++) {
        index = CHAR_TO_INDEX(str[i]);
        if (tmp->children[index] ==
            NULL) {  // if the children is null then create it
            tmp->children[index] = create();
        }
        tmp = tmp->children[index];
    }

    // to mark that the word has ended
    tmp->is_leaf = true;
}

bool lookup(Trie *dict, char *str) {
    int str_length = strlen(str);
    int index;

    Trie *tmp = dict;
    for (int i = 0; i < str_length; i++) {
        index = CHAR_TO_INDEX(str[i]);
        if (tmp->children[index] == NULL) {  // if the children is null in the
                                             // trei path then return false
            return false;
        }
        tmp = tmp->children[index];  // points to the next children
    }
    return tmp->is_leaf;
}

void destroy(Trie *dict) {  // recursion to destroy dict
    for (int i = 0; i < NUM_CHARS; i++) {
        if (dict->children[i] != NULL) {  // if there is a word on the node then
                                          // recurse on it to delete it
            destroy(dict->children[i]);
        }
    }
    free(dict);
}