make ./bin/libwordle.so
cd gui
./start.sh
