#pragma once

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "common.h"
#include "game.h"

exit_way openSettings(char **filename_, bool *quantum_, char **argv);